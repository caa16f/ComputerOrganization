Hello,

I was able to to implement almost everything correctly,
 the only thing I implemented with issues is the number of memory references is sometimes inconsistent with
the example cache.exe. The hits and misses along with all the other stats line up except for the memory references
and even then the memory references only miss up sometimes. Like I said very inconsistent. 


Other than that I believe everything to be correct. I was able to manage both the associativity and 
implement a LRU replacement strategy.

Thank you,
Carlos